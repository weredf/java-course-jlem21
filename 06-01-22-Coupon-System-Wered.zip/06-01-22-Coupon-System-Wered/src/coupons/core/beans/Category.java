package coupons.core.beans;

public enum Category {

	FOOD, ELECTRONICS, RESTAURANT, VACATION
}
