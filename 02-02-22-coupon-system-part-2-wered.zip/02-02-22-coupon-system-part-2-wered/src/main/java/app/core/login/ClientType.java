package app.core.login;

public enum ClientType {
	ADMINISTRATOR, COMPANY, CUSTOMER
}
