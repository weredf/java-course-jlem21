package app.core.entities;

public enum Category {

	FOOD, ELECTRONICS, RESTAURANT, VACATION
}
